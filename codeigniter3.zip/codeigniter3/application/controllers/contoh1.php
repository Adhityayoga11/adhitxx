<?php
class contoh1 extends CI_Controller {

	public function index()
	{
		echo "<h1> perkenalkan </h1>";
        echo "nama saya Alpin marifatullah
            saya tingal didaerah bekasi
            olahraga yang saya sukai adalah
            futsal";
	}
}