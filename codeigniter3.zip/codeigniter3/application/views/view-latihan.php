<html>
<head>
 <title>latihan 1</title>
</head>
<body>
    Halo teman.. Yuk kita belajar web programming !!!<br>
 Nilai 1 = <?= $nilai1; ?><br>
 Nilai 2 = <?= $nilai2; ?><br>
 ini hasil dari pemodelan dengan metode penjumlahan yaitu <?=
$nilai1 . " + " . $nilai2 . " = " . $hasil; ?>
</body>
</html>